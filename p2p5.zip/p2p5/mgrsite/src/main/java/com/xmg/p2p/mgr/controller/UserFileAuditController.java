package com.xmg.p2p.mgr.controller;


import com.xmg.p2p.base.query.UserFileQueryObject;
import com.xmg.p2p.base.service.IUserFileService;
import com.xmg.p2p.base.util.JSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//后端:风控资料审核
@Controller
public class UserFileAuditController {

    @Autowired
    private IUserFileService userFileService;

    //风控资料审核列表
    @RequestMapping("userFileAuth")
    public String userFileList(@ModelAttribute("qo") UserFileQueryObject qo, Model model) {
        model.addAttribute("pageResult", userFileService.query(qo));
        return "userFileAuth/list";
    }


    @RequestMapping("userFile_audit")
    @ResponseBody
    public JSONResult audit(Long id,int state,String remark,int score){
        userFileService.audit(id,state,remark,score);
        return new JSONResult();
    }
}
