package com.xmg.p2p.mgr.interceptor;

import com.xmg.p2p.base.util.UserContext;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//登录检查拦截器
public class CheckLoginInterceptor extends HandlerInterceptorAdapter {
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (UserContext.getCurrentUser() == null) {
            response.sendRedirect("/login.html");
            return false;
        }
        return true;
    }

}
