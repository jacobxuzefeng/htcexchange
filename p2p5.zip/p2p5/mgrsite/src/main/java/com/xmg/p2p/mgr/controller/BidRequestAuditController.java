package com.xmg.p2p.mgr.controller;

import com.xmg.p2p.base.domain.RealAuth;
import com.xmg.p2p.base.domain.UserFile;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.query.UserFileQueryObject;
import com.xmg.p2p.base.service.IRealAuthService;
import com.xmg.p2p.base.service.IUserFileService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.BidConst;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.business.domain.BidRequest;
import com.xmg.p2p.business.domain.BidRequestAuditHistory;
import com.xmg.p2p.business.query.BidRequestQueryObject;
import com.xmg.p2p.business.service.IBidRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

//后端:借款审核
@Controller
public class BidRequestAuditController {

    @Autowired
    private IBidRequestService bidRequestService;

    @Autowired
    private IUserinfoService userinfoService;
    @Autowired
    private IRealAuthService realAuthService;
    @Autowired
    private IUserFileService userFileService;


    //发标前审核列表
    @RequestMapping("bidrequest_publishaudit_list")
    public String publishAuditList(@ModelAttribute("qo") BidRequestQueryObject qo, Model model) {
        //处于待发布状态
        qo.setBidRequestState(BidConst.BIDREQUEST_STATE_PUBLISH_PENDING);
        model.addAttribute("pageResult", bidRequestService.query(qo));
        return "bidrequest/publish_audit";
    }

    //发标审核
    @RequestMapping("bidrequest_publishaudit")
    @ResponseBody
    public JSONResult publishAudit(Long id, int state, String remark) {
        bidRequestService.publishAudit(id, state, remark);
        return new JSONResult();
    }

    /**
     * 满标一审列表
     */
    @RequestMapping("bidrequest_audit1_list")
    public String bidRequestFullAudit1List(
            @ModelAttribute("qo") BidRequestQueryObject qo, Model model) {
        qo.setBidRequestState(BidConst.BIDREQUEST_STATE_APPROVE_PENDING_1);
        model.addAttribute("pageResult", this.bidRequestService.query(qo));
        return "bidrequest/audit1";
    }

    /**
     * 满标一审
     *
     * @param id
     * @param remark
     * @param state
     * @return
     */
    @RequestMapping("bidrequest_audit1")
    @ResponseBody
    public JSONResult bidRequestAudit1(Long id, String remark, int state) {
        this.bidRequestService.fullAudit1(id, remark, state);
        return new JSONResult();
    }

    /**
     * 满标二审列表
     */
    @RequestMapping("bidrequest_audit2_list")
    public String bidRequestFullAudit2List(
            @ModelAttribute("qo") BidRequestQueryObject qo, Model model) {
        qo.setBidRequestState(BidConst.BIDREQUEST_STATE_APPROVE_PENDING_2);
        model.addAttribute("pageResult", this.bidRequestService.query(qo));
        return "bidrequest/audit2";
    }

    /**
     * 满标二审
     *
     * @param id
     * @param remark
     * @param state
     * @return
     */
    @RequestMapping("bidrequest_audit2")
    @ResponseBody
    public JSONResult bidRequestAudit2(Long id, String remark, int state) {
        this.bidRequestService.fullAudit2(id, remark, state);
        return new JSONResult();
    }

    //查询借款详情
    @RequestMapping("borrow_info")
    public String bidRequestDetail(Long id, Model model) {
        BidRequest br = bidRequestService.get(id);//借款信息
        Userinfo userInfo = userinfoService.get(br.getCreateUser().getId());//借款人信息
        //借款所有的历史
        List<BidRequestAuditHistory> audits = bidRequestService.queryHistorysByBidRequestId(id);
        //借款人的实名认证信息
        RealAuth realAuth = realAuthService.get(userInfo.getRealAuthId());
        //借款人的风控资料
        UserFileQueryObject qo = new UserFileQueryObject();
        qo.setUserinfoId(br.getCreateUser().getId());//借款申请人
        qo.setState(UserFile.STATE_PASS);//审核通过
        qo.setPageSize(-1);//不使用分页设置
        List<UserFile> userFiles = userFileService.query(qo).getResult();

        model.addAttribute("bidRequest", br);
        model.addAttribute("userInfo", userInfo);
        model.addAttribute("audits", audits);
        model.addAttribute("realAuth", realAuth);
        model.addAttribute("userFiles", userFiles);

        return "bidrequest/borrow_info";
    }

}
