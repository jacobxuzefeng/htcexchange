package com.xmg.p2p.mgr.controller;

import com.xmg.p2p.base.query.VideoAuthQueryObject;
import com.xmg.p2p.base.service.ILogininfoService;
import com.xmg.p2p.base.service.IVideoAuthService;
import com.xmg.p2p.base.util.JSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

//后端:视频认证
@Controller
public class VideoAuthAuditController {

    @Autowired
    private IVideoAuthService videoAuthService;
    @Autowired
    private ILogininfoService logininfoService;


    //视频认证审核列表
    @RequestMapping("videoAuth")
    public String videoAuthList(@ModelAttribute("qo") VideoAuthQueryObject qo, Model model) {
        model.addAttribute("pageResult", videoAuthService.query(qo));
        return "videoAuth/list";
    }

    //视频认证审核
    @RequestMapping("videoAuth_audit")
    @ResponseBody
    public JSONResult audit(Long applierId, int state, String remark) {
        videoAuthService.audit(applierId,state,remark);
        return new JSONResult();
    }

    //自动补全
    @RequestMapping("autoComplete")
    @ResponseBody
    public List<Map<String,Object>> autoComplete(String keyword){
        return logininfoService.queryAutoComplete(keyword);
    }
}
