package com.xmg.p2p.mgr.controller;

import com.xmg.p2p.base.domain.Logininfo;
import com.xmg.p2p.base.service.ILogininfoService;
import com.xmg.p2p.base.util.JSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

//后端:系统登录
@Controller
public class LoginController {

    @Autowired
    private ILogininfoService logininfoService;

    //登录
    @RequestMapping("login")
    @ResponseBody
    public JSONResult login(String username, String password, HttpServletRequest request) {
        JSONResult jsonResult = new JSONResult();
        Logininfo current = logininfoService.login(username, password, request.getRemoteAddr(), Logininfo.USER_MANAGER);
        if (current == null) {
            jsonResult.mark("账户或密码错误");
        }
        return jsonResult;
    }

    //登录后,跳转到主页面
    @RequestMapping("index")
    public String gotoMainPage() {
        return "main";
    }
}
