package com.xmg.p2p.mgr.controller;

import com.xmg.p2p.base.domain.SystemDictionary;
import com.xmg.p2p.base.domain.SystemDictionaryItem;
import com.xmg.p2p.base.query.SystemDictionaryQueryObject;
import com.xmg.p2p.base.service.ISystemDictionaryService;
import com.xmg.p2p.base.util.JSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//后台:数据字典控制器
@Controller
public class SystemDictionaryController {

    @Autowired
    private ISystemDictionaryService systemDictionaryService;

    //数据字典目录列表
    @RequestMapping("systemDictionary_list")
    public String dicList(@ModelAttribute("qo") SystemDictionaryQueryObject qo, Model model) {
        model.addAttribute("pageResult", systemDictionaryService.queryDics(qo));
        return "systemdic/systemDictionary_list";
    }

    //数据字典保存或更新
    @RequestMapping("systemDictionary_update")
    @ResponseBody
    public JSONResult updateDic(SystemDictionary dic) {
        systemDictionaryService.saveOrUpdateDic(dic);
        return new JSONResult();
    }

    //数据字典明细列表
    @RequestMapping("systemDictionaryItem_list")
    public String itemList(@ModelAttribute("qo") SystemDictionaryQueryObject qo, Model model) {
        model.addAttribute("systemDictionaryGroups", systemDictionaryService.listAllDics());
        model.addAttribute("pageResult", systemDictionaryService.queryItems(qo));
        return "systemdic/systemDictionaryItem_list";
    }

    //数据字典保存或更新
    @RequestMapping("systemDictionaryItem_update")
    @ResponseBody
    public JSONResult updateItem(SystemDictionaryItem item) {
        systemDictionaryService.saveOrUpdateItem(item);
        return new JSONResult();
    }
}
