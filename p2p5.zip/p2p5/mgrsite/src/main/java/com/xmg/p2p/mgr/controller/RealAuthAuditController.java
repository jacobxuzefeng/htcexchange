package com.xmg.p2p.mgr.controller;


import com.xmg.p2p.base.query.RealAuthQueryObject;
import com.xmg.p2p.base.service.IRealAuthService;
import com.xmg.p2p.base.util.JSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//后端:实名认证审核
@Controller
public class RealAuthAuditController {

    @Autowired
    private IRealAuthService realAuthService;

    //实名认证审核列表
    @RequestMapping("realAuth")
    public String gotoPage(@ModelAttribute("qo") RealAuthQueryObject qo, Model model) {
        model.addAttribute("pageResult", realAuthService.query(qo));
        return "realAuth/list";
    }

    @RequestMapping("realAuth_audit")
    @ResponseBody
    public JSONResult audit(Long id, int state, String remark) {
        realAuthService.audit(id,state,remark);
        return new JSONResult();
    }
}
