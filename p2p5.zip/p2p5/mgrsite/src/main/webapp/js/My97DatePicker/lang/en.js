var $lang={
errAlertMsg: "Invalid date or the date out of range,redo or not?",
aWeekStr: ["wk", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
aLongWeekStr:["wk","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
aMonStr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
aLongMonStr: ["January","February","March","April","May","June","July","August","September","October","November","December"],
clearStr: "Clear",
todayStr: "Today",
okStr: "OK",
updateStr: "OK",
timeStr: "Time",
quickStr: "Quick Selection",
err_1: 'MinDate Cannot be bigger than MaxDate!'
}