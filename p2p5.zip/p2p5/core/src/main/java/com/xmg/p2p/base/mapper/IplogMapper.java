package com.xmg.p2p.base.mapper;

import com.xmg.p2p.base.domain.Iplog;
import com.xmg.p2p.base.query.IplogQueryObject;

import java.util.List;

public interface IplogMapper {
    int insert(Iplog record);

    List<Iplog> selectAll();

    int queryForCount(IplogQueryObject qo);

    List<?> query(IplogQueryObject qo);
}