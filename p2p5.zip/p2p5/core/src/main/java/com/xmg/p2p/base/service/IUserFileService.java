package com.xmg.p2p.base.service;

import com.xmg.p2p.base.domain.UserFile;
import com.xmg.p2p.base.query.UserFileQueryObject;
import com.xmg.p2p.base.util.PageResult;

import java.util.List;

public interface IUserFileService {

    PageResult query(UserFileQueryObject qo);

    /**
     * 申请保存一个风控资料信息
     *
     * @param fileName
     */
    void apply(String fileName);


    /**
     * 查询符合条件的风控资料列表
     *
     * @param choice 是否选择风控资料类型
     */
    List<UserFile> listUserFiles(boolean choice);


    /**
     * 风控资料选择分类类型
     *
     * @param ids       图片ID
     * @param fileTypes 类型ID
     */
    void choiceFileType(Long[] ids, Long[] fileTypes);

    /**
     * 风控资料审核
     *
     * @param id
     * @param state
     * @param remark
     * @param score
     */
    void audit(Long id, int state, String remark, int score);
}
