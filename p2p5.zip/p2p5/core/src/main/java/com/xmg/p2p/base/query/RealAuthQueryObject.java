package com.xmg.p2p.base.query;

import lombok.Getter;
import lombok.Setter;

//实名认证高级查询对象
@Getter
@Setter
public class RealAuthQueryObject extends BaseAuditQueryObject {
}
