package com.xmg.p2p.base.util;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JSONResult {
    private boolean success = true;
    private String msg;

    public void mark(String errorMsg) {
        this.success = false;
        this.msg = errorMsg;
    }
}
