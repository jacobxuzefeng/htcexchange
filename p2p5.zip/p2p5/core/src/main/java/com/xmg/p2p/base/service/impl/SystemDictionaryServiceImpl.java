package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.SystemDictionary;
import com.xmg.p2p.base.domain.SystemDictionaryItem;
import com.xmg.p2p.base.mapper.SystemDictionaryItemMapper;
import com.xmg.p2p.base.mapper.SystemDictionaryMapper;
import com.xmg.p2p.base.query.SystemDictionaryQueryObject;
import com.xmg.p2p.base.service.ISystemDictionaryService;
import com.xmg.p2p.base.util.PageResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SystemDictionaryServiceImpl implements ISystemDictionaryService {
    @Autowired
    private SystemDictionaryMapper dicMapper;
    @Autowired
    private SystemDictionaryItemMapper itemMapper;


    public PageResult queryDics(SystemDictionaryQueryObject qo) {
        int rows = dicMapper.queryForCount(qo);
        if (rows == 0) {
            return PageResult.empty(qo.getPageSize());
        }
        List<?> result = dicMapper.query(qo);
        return new PageResult(result, rows, qo.getCurrentPage(), qo.getPageSize());
    }

    public void saveOrUpdateDic(SystemDictionary dic) {
        if (dic.getId() == null) {
            dicMapper.insert(dic);
        } else {
            dicMapper.updateByPrimaryKey(dic);
        }
    }

    public PageResult queryItems(SystemDictionaryQueryObject qo) {
        int rows = itemMapper.queryForCount(qo);
        if (rows == 0) {
            return PageResult.empty(qo.getPageSize());
        }
        List<?> result = itemMapper.query(qo);
        return new PageResult(result, rows, qo.getCurrentPage(), qo.getPageSize());
    }

    public void saveOrUpdateItem(SystemDictionaryItem item) {
        if (item.getId() == null) {
            itemMapper.insert(item);
        } else {
            itemMapper.updateByPrimaryKey(item);
        }
    }

    public List<SystemDictionary> listAllDics() {
        return dicMapper.selectAll();
    }

    public List<SystemDictionaryItem> listItemsByDicSn(String systemDictionarySn) {
        return itemMapper.listItemsByDicSn(systemDictionarySn);
    }
}

