package com.xmg.p2p.base.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserFileQueryObject extends BaseAuditQueryObject {
    private Long userinfoId = -1L;//哪一个用户的风控资料
}
