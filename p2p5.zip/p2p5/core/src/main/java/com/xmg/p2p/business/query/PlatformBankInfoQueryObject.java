package com.xmg.p2p.business.query;

import com.xmg.p2p.base.query.BaseAuditQueryObject;

/**
 * 平台账户查询对象
 * 
 * @author Administrator
 * 
 */
public class PlatformBankInfoQueryObject extends BaseAuditQueryObject {

}
