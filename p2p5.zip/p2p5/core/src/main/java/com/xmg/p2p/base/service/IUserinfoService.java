package com.xmg.p2p.base.service;

import com.xmg.p2p.base.domain.Userinfo;

public interface IUserinfoService {
    void save(Userinfo info);

    void update(Userinfo info);

    Userinfo getCurrent();

    void bindPhone(String phoneNumber, String verifyCode);

    void bindEmail(String uuid);

    void saveOrUpdate(Userinfo userinfo);

    Userinfo get(Long id);
}
