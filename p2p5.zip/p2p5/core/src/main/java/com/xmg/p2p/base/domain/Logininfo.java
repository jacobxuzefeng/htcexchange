package com.xmg.p2p.base.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Logininfo extends BaseDomain {
    public static final int STATE_NORMAL = 0;
    public static final int STATE_LOCK = 1;
    public static final int USER_NORMAL = 0;
    public static final int USER_MANAGER = 1;

    private String username;
    private String password;
    private int state;//状态
    private int userType = USER_NORMAL;//用户类型
}
