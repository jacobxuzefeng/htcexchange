package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.RealAuth;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.mapper.RealAuthMapper;
import com.xmg.p2p.base.query.RealAuthQueryObject;
import com.xmg.p2p.base.service.IRealAuthService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.BitStateUtil;
import com.xmg.p2p.base.util.PageResult;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class RealAuthServiceImpl implements IRealAuthService {
    @Autowired
    private RealAuthMapper realAuthMapper;

    @Autowired
    private IUserinfoService userinfoService;

    public RealAuth get(Long id) {
        return realAuthMapper.selectByPrimaryKey(id);
    }

    public PageResult query(RealAuthQueryObject qo) {
        int rows = realAuthMapper.queryForCount(qo);
        if (rows == 0) {
            return PageResult.empty(qo.getPageSize());
        }
        List<?> result = realAuthMapper.query(qo);
        return new PageResult(result, rows, qo.getCurrentPage(), qo.getPageSize());
    }

    public void apply(RealAuth ra) {
        Userinfo current = userinfoService.getCurrent();
        if (!current.getHasRealAuth()) {
            RealAuth r = new RealAuth();
            //基本信息
            r.setRealName(ra.getRealName());
            r.setIdNumber(ra.getIdNumber());
            r.setAddress(ra.getAddress());
            r.setBornDate(ra.getBornDate());
            r.setSex(ra.getSex());
            r.setImage1(ra.getImage1());
            r.setImage2(ra.getImage2());
            //申请信息
            r.setApplier(UserContext.getCurrentUser());
            r.setApplyTime(new Date());
            r.setState(RealAuth.STATE_NORMAL);

            realAuthMapper.insert(r);
            current.setRealAuthId(r.getId());
            userinfoService.update(current);
        }
    }

    public void audit(Long id, int state, String remark) {
        //1:实名认证对象,并判断
        RealAuth ra = realAuthMapper.selectByPrimaryKey(id);
        if (ra != null && ra.getState() == RealAuth.STATE_NORMAL) {
            //2:设置实名认证审核信息
            ra.setAuditTime(new Date());
            ra.setAuditor(UserContext.getCurrentUser());
            ra.setState(state);
            ra.setRemark(remark);
            //3:查询出当前实名认证申请人
            Userinfo applier = userinfoService.get(ra.getApplier().getId());
            if (!applier.getHasRealAuth()) {
                if (state == RealAuth.STATE_PASS) {
                    //3:审核通过,修改状态码
                    applier.setRealName(ra.getRealName());
                    applier.setIdNumber(ra.getIdNumber());
                    applier.addState(BitStateUtil.OP_REAL_AUTH);
                } else {
                    //4:审核拒绝,把realAuthId置空
                    applier.setRealAuthId(null);
                }
                userinfoService.update(applier);
            }
            realAuthMapper.updateByPrimaryKey(ra);
        }
    }
}
