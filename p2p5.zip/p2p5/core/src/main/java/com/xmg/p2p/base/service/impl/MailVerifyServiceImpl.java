package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.MailVerify;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.mapper.MailVerifyMapper;
import com.xmg.p2p.base.service.IMailVerifyService;
import com.xmg.p2p.base.service.IUserinfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class MailVerifyServiceImpl implements IMailVerifyService {

    @Autowired
    private IUserinfoService userinfoService;
    @Autowired
    private MailVerifyMapper mailVerifyMapper;

    public void sendEMail(String email) {
        Userinfo current = userinfoService.getCurrent();
        String uuid = UUID.randomUUID().toString();
        try {

            String str = "这是一封激活邮件:点击<a href='/bindEmail.do?uuid=" + uuid + "'>激活</a>";
            System.out.println("发送给" + email + ",内容为:" + str);

            MailVerify mailVerify = new MailVerify();
            mailVerify.setEmail(email);
            mailVerify.setSendTime(new Date());
            mailVerify.setUserinfoId(current.getId());
            mailVerify.setUuid(uuid);
            mailVerifyMapper.insert(mailVerify);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("发送验证邮件失败");
        }
    }
}
