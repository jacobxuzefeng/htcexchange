package com.xmg.p2p.base.vo;

import lombok.Getter;

import java.util.Date;

@Getter
public class VerifyCodeVO {
    private String code;        //验证码
    private String phoneNumber; //绑定手机号码
    private Date sendTime;    //发生时间

    public VerifyCodeVO(String code, String phoneNumber, Date sendTime) {
        this.code = code;
        this.phoneNumber = phoneNumber;
        this.sendTime = sendTime;
    }
}
