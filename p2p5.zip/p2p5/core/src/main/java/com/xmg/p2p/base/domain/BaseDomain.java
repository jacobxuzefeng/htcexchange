package com.xmg.p2p.base.domain;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class BaseDomain {
    protected Long id;
}
