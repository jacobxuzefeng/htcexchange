package com.xmg.p2p.base.domain;

import lombok.Getter;
import lombok.Setter;


//视频认证对象
@Getter
@Setter
public class VideoAuth extends BaseAuditDomain {
}
