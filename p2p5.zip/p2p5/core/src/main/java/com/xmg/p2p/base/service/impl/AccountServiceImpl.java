package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.Account;
import com.xmg.p2p.base.mapper.AccountMapper;
import com.xmg.p2p.base.service.IAccountService;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements IAccountService {
    @Autowired
    private AccountMapper accountMapper;

    public void save(Account account) {
        accountMapper.insert(account);
    }

    public void update(Account account) {
        int row = accountMapper.updateByPrimaryKey(account);
        if (row == 0) {
            throw new RuntimeException("乐观锁失败:Account-" + account.getId());
        }
    }

    public Account getCurrent() {
        return accountMapper.selectByPrimaryKey(UserContext.getCurrentUser().getId());
    }

    public Account get(Long id) {
        return accountMapper.selectByPrimaryKey(id);
    }
}
