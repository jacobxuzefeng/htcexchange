package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.MailVerify;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.mapper.MailVerifyMapper;
import com.xmg.p2p.base.mapper.UserinfoMapper;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.service.IVerifyCodeService;
import com.xmg.p2p.base.util.BitStateUtil;
import com.xmg.p2p.base.util.DateUtil;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserinfoServiceImpl implements IUserinfoService {
    @Autowired
    private UserinfoMapper userinfoMapper;
    @Autowired
    private IVerifyCodeService verifyCodeService;
    @Autowired
    private MailVerifyMapper mailVerifyMapper;

    public void save(Userinfo info) {
        userinfoMapper.insert(info);
    }

    public void update(Userinfo info) {
        int row = userinfoMapper.updateByPrimaryKey(info);
        if (row == 0) {
            throw new RuntimeException("乐观锁失败:Userinfo-" + info.getId());
        }
    }

    public Userinfo getCurrent() {
        return userinfoMapper.selectByPrimaryKey(UserContext.getCurrentUser().getId());
    }

    public void bindPhone(String phoneNumber, String verifyCode) {
        if (!verifyCodeService.validate(phoneNumber, verifyCode)) {
            throw new RuntimeException("验证码不正确!");
        }
        Userinfo current = this.getCurrent();
        if (!current.getHasBindPhone()) {
            current.setPhoneNumber(phoneNumber);
            current.addState(BitStateUtil.OP_BIND_PHONE);
            this.update(current);
        }

    }

    public void bindEmail(String uuid) {
        MailVerify mv = mailVerifyMapper.selectByUUID(uuid);
        if (mv == null || DateUtil.getBetweenTime(new Date(), mv.getSendTime()) >= 5 * 24 * 3600) {
            throw new RuntimeException("绑定邮箱失败,请重新绑定!");
        }
        Userinfo current = userinfoMapper.selectByPrimaryKey(mv.getUserinfoId());
        if (!current.getHasBindEmail()) {
            current.setEmail(mv.getEmail());
            current.addState(BitStateUtil.OP_BIND_EMAIL);
            this.update(current);
        }
    }

    public void saveOrUpdate(Userinfo info) {
        Userinfo current = this.getCurrent();
        current.setIncomeGrade(info.getIncomeGrade());
        current.setEducationBackground(info.getEducationBackground());
        current.setHouseCondition(info.getHouseCondition());
        current.setKidCount(info.getKidCount());
        current.setMarriage(info.getMarriage());
        if (!current.getHasBasicInfo()) {
            current.addState(BitStateUtil.OP_BASIC_INFO);
        }
        this.update(current);
    }

    public Userinfo get(Long id) {
        return userinfoMapper.selectByPrimaryKey(id);
    }
}
