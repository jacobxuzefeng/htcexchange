package com.xmg.p2p.base.service;

import com.xmg.p2p.base.domain.RealAuth;
import com.xmg.p2p.base.query.RealAuthQueryObject;
import com.xmg.p2p.base.util.PageResult;

public interface IRealAuthService {
    RealAuth get(Long id);

    PageResult query(RealAuthQueryObject qo);

    /**
     * 实名认证申请
     *
     * @param ra
     */
    void apply(RealAuth ra);


    /**
     * 实名认证审核
     *
     * @param id
     * @param state
     * @param remark
     */
    void audit(Long id, int state, String remark);
}
