package com.xmg.p2p.base.service;


import com.xmg.p2p.base.domain.SystemDictionary;
import com.xmg.p2p.base.domain.SystemDictionaryItem;
import com.xmg.p2p.base.query.SystemDictionaryQueryObject;
import com.xmg.p2p.base.util.PageResult;

import java.util.List;

public interface ISystemDictionaryService {

    PageResult queryDics(SystemDictionaryQueryObject qo);

    void saveOrUpdateDic(SystemDictionary dic);

    PageResult queryItems(SystemDictionaryQueryObject qo);

    void saveOrUpdateItem(SystemDictionaryItem item);

    List<SystemDictionary> listAllDics();

    /**
     * 根据 数据字典分类sn,查询对应的明细
     * @param systemDictionarySn
     */
    List<SystemDictionaryItem> listItemsByDicSn(String systemDictionarySn);
}

