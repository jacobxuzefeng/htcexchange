package com.xmg.p2p.base.domain;


import com.alibaba.fastjson.JSON;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

//风控资料
@Getter
@Setter
public class UserFile extends BaseAuditDomain {
    private int score;//审核得分
    private String image;//图片
    private SystemDictionaryItem fileType;//风控资料类型

    public String getJsonString() {
        Map<String, Object> json = new HashMap<>();
        json.put("id", id);
        json.put("image", image);
        json.put("applier", applier.getUsername());
        json.put("fileType", fileType.getTitle());
        return JSON.toJSONString(json);
    }
}
