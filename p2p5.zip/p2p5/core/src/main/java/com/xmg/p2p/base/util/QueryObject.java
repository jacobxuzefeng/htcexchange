package com.xmg.p2p.base.util;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
abstract public class QueryObject {
    private Integer currentPage = 1;
    private Integer pageSize = 10;

    public int getStart() {
        return (currentPage - 1) * pageSize;
    }


    public boolean hasLength(String str) {
        return str != null && !"".equals(str.trim());
    }

}
