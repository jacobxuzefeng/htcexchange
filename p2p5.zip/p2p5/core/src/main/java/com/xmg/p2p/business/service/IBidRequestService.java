package com.xmg.p2p.business.service;

import com.xmg.p2p.base.util.PageResult;
import com.xmg.p2p.business.domain.BidRequest;
import com.xmg.p2p.business.domain.BidRequestAuditHistory;
import com.xmg.p2p.business.query.BidRequestQueryObject;
import com.xmg.p2p.business.query.PaymentScheduleQueryObject;

import java.math.BigDecimal;
import java.util.List;

public interface IBidRequestService {
    void update(BidRequest br);

    BidRequest get(Long id);

    PageResult query(BidRequestQueryObject qo);

    /**
     * 借款申请
     *
     * @param br
     */
    void apply(BidRequest br);

    /**
     * 发标审核
     *
     * @param bidRequestId
     * @param state
     * @param remark
     */
    void publishAudit(Long bidRequestId, int state, String remark);

    /**
     * 查询指定借款对应的所有审核历史信息
     *
     * @param bidRequestId
     * @return
     */
    List<BidRequestAuditHistory> queryHistorysByBidRequestId(Long bidRequestId);

    /**
     * 首页显示的处于：1，投标中；2，还款中；3已完成的标的5个标；注意，按照投标中>还款中>已完成的顺序排列
     * @return
     */
    List<BidRequest> listIndexBidRequest();

    /**
     *
     * 投标
     * @param bidRequestId   针对哪一个借款ID
     * @param amount         投标金额
     */
    void bid(Long bidRequestId, BigDecimal amount);

    public void fullAudit1(Long id, String remark, int state);

    public void fullAudit2(Long id, String remark, int state);

    public void doReturnMoney(Long id);

    PageResult queryPaymentSchedule(PaymentScheduleQueryObject qo);
}
