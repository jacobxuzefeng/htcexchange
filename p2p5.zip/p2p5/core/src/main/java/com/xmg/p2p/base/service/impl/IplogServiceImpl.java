package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.mapper.IplogMapper;
import com.xmg.p2p.base.query.IplogQueryObject;
import com.xmg.p2p.base.service.IIplogService;
import com.xmg.p2p.base.util.PageResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IplogServiceImpl implements IIplogService {
    @Autowired
    private IplogMapper iplogMapper;

    public PageResult query(IplogQueryObject qo) {
        int rows = iplogMapper.queryForCount(qo);
        if (rows == 0) {
            return PageResult.empty(qo.getPageSize());
        }
        List<?> result = iplogMapper.query(qo);
        return new PageResult(result, rows, qo.getCurrentPage(), qo.getPageSize());
    }
}
