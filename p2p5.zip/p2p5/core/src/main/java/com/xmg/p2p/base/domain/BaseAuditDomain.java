package com.xmg.p2p.base.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

//认证基类
@Getter
@Setter
abstract public class BaseAuditDomain extends BaseDomain {
    public static final int STATE_NORMAL = 0;
    public static final int STATE_PASS = 1;
    public static final int STATE_REJECT = 2;

    //审核信息
    protected int state;
    protected String remark;
    protected Logininfo applier;
    protected Date applyTime;
    protected Logininfo auditor;
    protected Date auditTime;


    public String getDisplayState() {
        switch (this.state) {
            case STATE_NORMAL:
                return "待审核";
            case STATE_PASS:
                return "审核通过";
            case STATE_REJECT:
                return "审核拒绝";
            default:
                return "";
        }
    }
}
