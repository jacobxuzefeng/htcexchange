package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.service.IVerifyCodeService;
import com.xmg.p2p.base.util.DateUtil;
import com.xmg.p2p.base.util.UserContext;
import com.xmg.p2p.base.vo.VerifyCodeVO;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class VerifyCodeServiceImpl implements IVerifyCodeService {

    public void sendVerifyCode(String phoneNumber) {
        VerifyCodeVO vo = UserContext.getVerifyCodeVO();
        if (vo != null && DateUtil.getBetweenTime(new Date(), vo.getSendTime()) < 180) {
            throw new RuntimeException("验证码发送太频繁");
        }
        String code = UUID.randomUUID().toString().substring(0, 4);
        vo = new VerifyCodeVO(code, phoneNumber, new Date());
        System.out.println("给" + phoneNumber + ",发送:" + code);
        UserContext.setVerifyCodeVO(vo);
    }

    public boolean validate(String phoneNumber, String verifyCode) {
        VerifyCodeVO vo = UserContext.getVerifyCodeVO();
        return vo != null && DateUtil.getBetweenTime(new Date(), vo.getSendTime()) < 300
                && vo.getCode().equals(verifyCode) && vo.getPhoneNumber().equals(phoneNumber);
    }
}
