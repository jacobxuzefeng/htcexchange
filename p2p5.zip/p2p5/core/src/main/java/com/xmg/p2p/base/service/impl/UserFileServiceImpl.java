package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.SystemDictionaryItem;
import com.xmg.p2p.base.domain.UserFile;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.mapper.UserFileMapper;
import com.xmg.p2p.base.query.UserFileQueryObject;
import com.xmg.p2p.base.service.IUserFileService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.PageResult;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class UserFileServiceImpl implements IUserFileService {

    @Autowired
    private UserFileMapper userFileMapper;

    @Autowired
    private IUserinfoService userinfoService;

    public PageResult query(UserFileQueryObject qo) {
        int rows = userFileMapper.queryForCount(qo);
        if (rows == 0) {
            return PageResult.empty(qo.getPageSize());
        }
        List<?> result = userFileMapper.query(qo);
        return new PageResult(result, rows, qo.getCurrentPage(), qo.getPageSize());
    }

    public void apply(String fileName) {
        UserFile uf = new UserFile();
        uf.setImage(fileName);
        uf.setState(UserFile.STATE_NORMAL);
        uf.setApplier(UserContext.getCurrentUser());//空指针
        uf.setApplyTime(new Date());
        userFileMapper.insert(uf);
    }

    public List<UserFile> listUserFiles(boolean choice) {
        return userFileMapper.listUserFiles(choice, UserContext.getCurrentUser().getId());
    }

    public void choiceFileType(Long[] ids, Long[] fileTypes) {
        if (ids != null && fileTypes != null && ids.length == fileTypes.length) {
            for (int index = 0; index < ids.length; index++) {
                UserFile uf = userFileMapper.selectByPrimaryKey(ids[index]);
                //判断当前用户是否是申请人
                if (uf.getApplier().getId().equals(UserContext.getCurrentUser().getId())) {
                    SystemDictionaryItem fType = new SystemDictionaryItem();
                    fType.setId(fileTypes[index]);
                    uf.setFileType(fType);
                    userFileMapper.updateByPrimaryKey(uf);
                }
            }
        }
    }

    public void audit(Long id, int state, String remark, int score) {
        //查询出风控资料对象,并判断
        UserFile uf = userFileMapper.selectByPrimaryKey(id);
        if (uf != null && uf.getState() == UserFile.STATE_NORMAL) {
            uf.setAuditor(UserContext.getCurrentUser());
            uf.setAuditTime(new Date());
            uf.setScore(score);
            uf.setRemark(remark);
            uf.setState(state);

            userFileMapper.updateByPrimaryKey(uf);

            //审核通过,申请人的分数增加
            if (state == UserFile.STATE_PASS) {
                Userinfo applier = userinfoService.get(uf.getApplier().getId());
                applier.setScore(applier.getScore() + score);
                userinfoService.update(applier);
            }
        }
    }
}

