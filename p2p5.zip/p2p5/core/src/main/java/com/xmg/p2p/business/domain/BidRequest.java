package com.xmg.p2p.business.domain;

import com.alibaba.fastjson.JSON;
import com.xmg.p2p.base.domain.BaseDomain;
import com.xmg.p2p.base.domain.Logininfo;
import com.xmg.p2p.base.util.BidConst;
import com.xmg.p2p.business.util.CalculatetUtil;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.xmg.p2p.base.util.BidConst.*;


//借款对象
@Getter
@Setter
public class BidRequest extends BaseDomain {
    private int version;// 版本号
    private int returnType;// 还款类型(等额本息)
    private int bidRequestType;// 借款类型(信用标)
    private int bidRequestState;// 借款状态
    private BigDecimal bidRequestAmount;// 借款总金额
    private BigDecimal currentRate;// 年化利率
    private BigDecimal minBidAmount;// 最小投標金额
    private int monthes2Return;// 还款月数
    private int bidCount = 0;// 已投标次数(冗余)
    private BigDecimal totalRewardAmount;// 总回报金额(总利息)
    private BigDecimal currentSum = BidConst.ZERO;// 当前已投标总金额
    private String title;// 借款标题
    private String description;// 借款描述
    private String note;// 风控意见
    private Date disableDate;// 招标截止日期
    private int disableDays;// 招标天数
    private Logininfo createUser;// 借款人
    private Date applyTime;// 申请时间
    private Date publishTime;// 发标时间

    private List<Bid> bids;// 针对该借款的投标


    //投标进度
    public int getPersent(){
        return this.currentSum.divide(this.bidRequestAmount).multiply(CalculatetUtil.ONE_HUNDRED).intValue();
    }

    //还需要的金额
    public BigDecimal getRemainAmount(){
        return this.bidRequestAmount.subtract(this.currentSum);
    }

    public String getJsonString() {
        Map<String, Object> json = new HashMap<>();

        json.put("id",id);
        json.put("username",createUser.getUsername());
        json.put("title",title);
        json.put("bidRequestAmount",bidRequestAmount);
        json.put("currentRate",currentRate);
        json.put("monthes2Return",monthes2Return);
        json.put("returnType",this.getDisplayReturnType());
        json.put("totalRewardAmount",totalRewardAmount);

        return JSON.toJSONString(json);
    }

    //还款方式
    public String getDisplayReturnType() {
        return returnType == BidConst.RETURN_TYPE_MONTH_INTEREST_PRINCIPAL ? "等额本息" : "按月到期";
    }

    //借款状态
    public String getDisplayBidRequestState() {
        switch (this.bidRequestState) {
            case BIDREQUEST_STATE_PUBLISH_PENDING:
                return "待发布";
            case BIDREQUEST_STATE_BIDDING:
                return "招标中";
            case BIDREQUEST_STATE_UNDO:
                return "已撤销";
            case BIDREQUEST_STATE_BIDDING_OVERDUE:
                return "流标";
            case BIDREQUEST_STATE_APPROVE_PENDING_1:
                return "满标一审";
            case BIDREQUEST_STATE_APPROVE_PENDING_2:
                return "满标二审";
            case BIDREQUEST_STATE_REJECTED:
                return "满标审核被拒";
            case BIDREQUEST_STATE_PAYING_BACK:
                return "还款中";
            case BIDREQUEST_STATE_COMPLETE_PAY_BACK:
                return "完成";
            case BIDREQUEST_STATE_PAY_BACK_OVERDUE:
                return "逾期";
            case BIDREQUEST_STATE_PUBLISH_REFUSE:
                return "发标拒绝";
            default:
                return "";
        }
    }
}
