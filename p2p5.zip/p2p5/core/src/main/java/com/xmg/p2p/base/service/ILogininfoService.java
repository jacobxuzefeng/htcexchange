package com.xmg.p2p.base.service;

import com.xmg.p2p.base.domain.Logininfo;

import java.util.List;
import java.util.Map;

public interface ILogininfoService {
    /**
     * 注册
     *
     * @param username
     * @param password
     */
    void register(String username, String password);

    /**
     * 监测注册账号是否存在
     *
     * @param username
     * @return
     */
    boolean checkUsernameExist(String username);

    /**
     * 登录操作
     *
     * @param username
     * @param password
     * @return
     */
    Logininfo login(String username, String password, String ip, int userType);

    /**
     * 初始化第一个管理员
     */
    void initAdmin();

    /**
     * 查询自动补全的数据   :[{id:1,username:'a'},{id:2,username:'b'}]
     * @param keyword
     * @return
     */

    List<Map<String,Object>> queryAutoComplete(String keyword);
}
