package com.xmg.p2p.base.domain;

import com.alibaba.fastjson.JSON;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
public class SystemDictionaryItem extends BaseDomain {
    private Long parentId;//分类ID
    private String title;//名称
    private int sequence;//顺序


    public String getJsonString() {
        Map<String, Object> json = new HashMap<>();
        json.put("id", id);
        json.put("parentId", parentId);
        json.put("title", title);
        json.put("sequence", sequence);
        return JSON.toJSONString(json);
    }
}
