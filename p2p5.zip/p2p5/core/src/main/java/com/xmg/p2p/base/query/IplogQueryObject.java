package com.xmg.p2p.base.query;

import com.xmg.p2p.base.util.DateUtil;
import com.xmg.p2p.base.util.QueryObject;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Getter
@Setter
public class IplogQueryObject extends QueryObject {
    //登录时间段
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date beginDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endDate;
    //登录状态
    private int state = -1;//
    //登录账户
    private String username;
    //用户类型
    private int userType = -1;

    public String getUsername() {
        return hasLength(username) ? username : null;
    }

    public Date getEndDate() {
        return endDate != null ? DateUtil.getEndDate(endDate) : null;
    }
}
