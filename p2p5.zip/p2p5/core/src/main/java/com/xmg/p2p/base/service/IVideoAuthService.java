package com.xmg.p2p.base.service;

import com.xmg.p2p.base.query.VideoAuthQueryObject;
import com.xmg.p2p.base.util.PageResult;

public interface IVideoAuthService {
    PageResult query(VideoAuthQueryObject qo);

    /**
     * 视频认证审核
     *
     * @param applierId
     * @param state
     * @param remark
     */
    void audit(Long applierId, int state, String remark);
}
