package com.xmg.p2p.business.query;

import com.xmg.p2p.base.query.BaseAuditQueryObject;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BidRequestQueryObject extends BaseAuditQueryObject {
    private int bidRequestState = -1;//借款状态

    private int[] states;//借款的任意一种状态

    private String orderBy;//排序规则,如: br.bidRequestState ASC
}
