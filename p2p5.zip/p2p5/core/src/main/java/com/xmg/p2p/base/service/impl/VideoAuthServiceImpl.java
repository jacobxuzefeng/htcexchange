package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.Logininfo;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.domain.VideoAuth;
import com.xmg.p2p.base.mapper.VideoAuthMapper;
import com.xmg.p2p.base.query.VideoAuthQueryObject;
import com.xmg.p2p.base.service.ILogininfoService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.service.IVideoAuthService;
import com.xmg.p2p.base.util.BitStateUtil;
import com.xmg.p2p.base.util.PageResult;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class VideoAuthServiceImpl implements IVideoAuthService {
    @Autowired
    private VideoAuthMapper videoAuthMapper;

    @Autowired
    private IUserinfoService userinfoService;

    @Autowired
    private ILogininfoService logininfoService;

    public PageResult query(VideoAuthQueryObject qo) {
        int rows = videoAuthMapper.queryForCount(qo);
        if (rows == 0) {
            return PageResult.empty(qo.getPageSize());
        }
        List<?> result = videoAuthMapper.query(qo);
        return new PageResult(result, rows, qo.getCurrentPage(), qo.getPageSize());
    }

    public void audit(Long applierId, int state, String remark) {
        //查询出申请人,判断
        Userinfo applier = userinfoService.get(applierId);
        if (applier != null && !applier.getHasVideoAuth()) {
            //如果没有认证过,创建视频认证对象,设置属性
            VideoAuth va = new VideoAuth();
            Logininfo applierLoginInfo = new Logininfo();
            applierLoginInfo.setId(applierId);
            va.setApplier(applierLoginInfo);
            va.setApplyTime(new Date());
            va.setAuditor(UserContext.getCurrentUser());
            va.setAuditTime(new Date());
            va.setState(state);
            va.setRemark(remark);

            videoAuthMapper.insert(va);

            //如果审核通过,更新状态码
            if (state == VideoAuth.STATE_PASS) {
                applier.addState(BitStateUtil.OP_VIDEO_AUTH);

                userinfoService.update(applier);
            }
        }
    }
}
