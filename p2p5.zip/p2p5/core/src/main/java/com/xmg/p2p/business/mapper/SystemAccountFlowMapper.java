package com.xmg.p2p.business.mapper;

import com.xmg.p2p.business.domain.SystemAccountFlow;

public interface SystemAccountFlowMapper {

	int insert(SystemAccountFlow record);

}