package com.xmg.p2p.base.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

import static com.xmg.p2p.base.domain.Logininfo.USER_NORMAL;

//登录日志
@Getter
@Setter
public class Iplog extends BaseDomain {
    public static final int LOGIN_SUCCESS = 0;
    public static final int LOGIN_FALLED = 1;

    private String username;//登录用户名
    private String ip;//登录IP
    private Date loginTime;//登录时间
    private int state = LOGIN_SUCCESS;//登录状态
    private int userType = USER_NORMAL;

    public String getDisplayState() {
        return state == LOGIN_SUCCESS ? "登录成功" : "登录失败";
    }
    public String getDisplayUserType() {
        return userType == USER_NORMAL ? "普通用户" : "管理员";
    }
}
