package com.xmg.p2p.base.util;

import com.xmg.p2p.base.domain.Logininfo;
import com.xmg.p2p.base.vo.VerifyCodeVO;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpSession;

public class UserContext {

    public static final String USER_IN_SESSION = "logininfo";
    public static final String VERIFYCODEVO_IN_SESSION = "verifycodevo_in_session";

    private static HttpSession getSession() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
    }

    public static void setCurrentUser(Logininfo current) {
        HttpSession session = getSession();
        session.setAttribute(USER_IN_SESSION, current);
    }

    public static void setVerifyCodeVO(VerifyCodeVO vo) {
        HttpSession session = getSession();
        session.setAttribute(VERIFYCODEVO_IN_SESSION, vo);
    }

    public static Logininfo getCurrentUser() {
        return (Logininfo) getSession().getAttribute(USER_IN_SESSION);
    }


    public static VerifyCodeVO getVerifyCodeVO() {
        return (VerifyCodeVO) getSession().getAttribute(VERIFYCODEVO_IN_SESSION);
    }

}
