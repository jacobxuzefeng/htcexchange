package com.xmg.p2p.base.service;

public interface IMailVerifyService {
    /*
        发送邮箱认证
     */
    void sendEMail(String email);
}
