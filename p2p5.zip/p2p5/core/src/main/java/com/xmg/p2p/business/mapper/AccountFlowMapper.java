package com.xmg.p2p.business.mapper;

import com.xmg.p2p.business.domain.AccountFlow;

public interface AccountFlowMapper {
	int insert(AccountFlow record);

}