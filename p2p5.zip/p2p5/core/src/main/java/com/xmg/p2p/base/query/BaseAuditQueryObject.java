package com.xmg.p2p.base.query;

import com.xmg.p2p.base.util.DateUtil;
import com.xmg.p2p.base.util.QueryObject;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

//审核高级查询对象基类
@Getter
@Setter
public class BaseAuditQueryObject extends QueryObject {
    protected int state = -1;//审核状态
    protected Date beginDate;//申请开始时间
    protected Date endDate;//申请结束时间

    public Date getEndDate() {
        return endDate != null ? DateUtil.getEndDate(endDate) : null;
    }
}
