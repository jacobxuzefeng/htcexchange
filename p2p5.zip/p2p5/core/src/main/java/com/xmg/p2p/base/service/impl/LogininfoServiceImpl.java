package com.xmg.p2p.base.service.impl;

import com.xmg.p2p.base.domain.Account;
import com.xmg.p2p.base.domain.Iplog;
import com.xmg.p2p.base.domain.Logininfo;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.mapper.IplogMapper;
import com.xmg.p2p.base.mapper.LogininfoMapper;
import com.xmg.p2p.base.service.IAccountService;
import com.xmg.p2p.base.service.ILogininfoService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.BidConst;
import com.xmg.p2p.base.util.MD5;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class LogininfoServiceImpl implements ILogininfoService {
    @Autowired
    private LogininfoMapper logininfoMapper;
    @Autowired
    private IUserinfoService userinfoService;
    @Autowired
    private IAccountService accountService;
    @Autowired
    private IplogMapper iplogMapper;

    public void register(String username, String password) {
        if (checkUsernameExist(username)) {
            throw new RuntimeException("该账号已经被注册!");
        }
        Logininfo info = new Logininfo();
        info.setUsername(username);
        info.setPassword(MD5.encode(password));
        info.setState(Logininfo.STATE_NORMAL);
        info.setUserType(Logininfo.USER_NORMAL);
        logininfoMapper.insert(info);

        Userinfo userinfo = new Userinfo();
        userinfo.setId(info.getId());
        userinfoService.save(userinfo);

        Account account = new Account();
        account.setId(info.getId());
        accountService.save(account);
    }

    public boolean checkUsernameExist(String username) {
        return logininfoMapper
                .getCountByUsername(username) > 0;
    }

    public Logininfo login(String username, String password, String ip, int userType) {
        Logininfo current = logininfoMapper.checkLogin(username, MD5.encode(password), userType);
        Iplog iplog = new Iplog();
        iplog.setUsername(username);
        iplog.setLoginTime(new Date());
        iplog.setUserType(userType);
        iplog.setIp(ip);
        if (current != null) {
            //存储到session中
            UserContext.setCurrentUser(current);
            iplog.setState(Iplog.LOGIN_SUCCESS);
        } else {
            iplog.setState(Iplog.LOGIN_FALLED);
        }
        iplogMapper.insert(iplog);
        return current;
    }

    public void initAdmin() {
        if (logininfoMapper.getCountByUserType(Logininfo.USER_MANAGER) == 0) {
            Logininfo logininfo = new Logininfo();
            logininfo.setUsername(BidConst.DEFAULT_SYSTEM_ADMIN_USERNAME);
            logininfo.setPassword(MD5.encode(BidConst.DEFAULT_SYSTEM_ADMIN_PASSWORD));
            logininfo.setState(Logininfo.STATE_NORMAL);
            logininfo.setUserType(Logininfo.USER_MANAGER);
            logininfoMapper.insert(logininfo);
        }
    }

    @Override
    public List<Map<String, Object>> queryAutoComplete(String keyword) {
        return logininfoMapper.queryAutoComplete(keyword);
    }
}
