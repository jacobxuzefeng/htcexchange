package com.xmg.p2p.base.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

//邮件校验
@Getter
@Setter
public class MailVerify extends BaseDomain {
    private String email;//绑定邮箱
    private Long userinfoId;
    private String uuid;
    private Date sendTime;
}
