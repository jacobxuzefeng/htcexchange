package com.xmg.p2p.base.service;

/**
 * 手机验证业务
 */
public interface IVerifyCodeService {

    void sendVerifyCode(String phoneNumer);

    boolean validate(String phoneNumber, String verifyCode);
}
