package com.xmg.p2p.controller;

import com.xmg.p2p.base.domain.UserFile;
import com.xmg.p2p.base.service.ISystemDictionaryService;
import com.xmg.p2p.base.service.IUserFileService;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.util.RequiredLogin;
import com.xmg.p2p.util.UploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import java.util.List;

//前端:上传风控资料
@Controller
public class UserFileController {

    @Autowired
    private ServletContext servletContext;

    @Autowired
    private IUserFileService userFileService;

    @Autowired
    private ISystemDictionaryService systemDictionaryService;


    //进入风控资料上传或列表页面
    @RequiredLogin
    @RequestMapping("userFile")
    public String userFile(Model model, HttpSession session) {
        //模拟:待审核或已审核的风控资料
        List<UserFile> userFiles = userFileService.listUserFiles(false);

        model.addAttribute("jsessionid", session.getId());
        if (userFiles.size() > 0) {
            //如果存在没有选择类型分风控资料列表
            model.addAttribute("userFiles", userFiles);
            model.addAttribute("fileTypes", systemDictionaryService.listItemsByDicSn("userFileType"));
            return "userFiles_commit";
        } else {
            //已经选择了风控资料类型列表
            model.addAttribute("userFiles", userFileService.listUserFiles(true));
            return "userFiles";
        }
    }

    //上传一个风控资料文件
    @RequiredLogin
    @RequestMapping("uploadUserFile")
    @ResponseBody
    public String uploadUserFile(MultipartFile file) {
        String fileName = UploadUtil.upload(file, servletContext.getRealPath("/upload"));
        //保存一个风控资料对象信息
        userFileService.apply("/upload/" + fileName);
        return "/upload/" + fileName;
    }


    @RequiredLogin
    @RequestMapping("userFile_selectType")
    @ResponseBody
    public JSONResult choiceFileType(Long[] id, Long[] fileType) {
        userFileService.choiceFileType(id, fileType);
        return new JSONResult();
    }
}
