package com.xmg.p2p.controller;

import com.xmg.p2p.business.service.IBidRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

//前端:首页
@Controller
public class IndexController {

    @Autowired
    private IBidRequestService bidRequestService;

    //首页
    @RequestMapping("index")
    public String index(Model model) {
        model.addAttribute("bidRequests", bidRequestService.listIndexBidRequest());
        return "main";
    }
}
