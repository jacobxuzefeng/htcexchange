package com.xmg.p2p.controller;

import com.xmg.p2p.base.service.IAccountService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.BidConst;
import com.xmg.p2p.base.util.UserContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

//前端:借款首页
@Controller
public class BorrowIndexController {
    @Autowired
    private IUserinfoService userinfoService;
    @Autowired
    private IAccountService accountService;

    //调整到我要借款页面
    @RequestMapping("borrow")
    public String borrow(Model model) {
        if (UserContext.getCurrentUser() != null) {
            model.addAttribute("userinfo", userinfoService.getCurrent());
            model.addAttribute("account", accountService.getCurrent());
            model.addAttribute("creditBorrowScore", BidConst.DEFAULT_CREDIT_BORROW_SCORE);
            return "borrow";
        }
        return "redirect:borrow.html";
    }
}

