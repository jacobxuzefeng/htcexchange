package com.xmg.p2p.controller;

import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.service.ISystemDictionaryService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.util.RequiredLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//前端:用户基本资料
@Controller
public class UserinfoController {

    @Autowired
    private ISystemDictionaryService systemDictionaryService;

    @Autowired
    private IUserinfoService userinfoService;

    //进入基本信息认证页面
    @RequiredLogin
    @RequestMapping("basicInfo")
    public String gotoPage(Model model) {
        model.addAttribute("userinfo",userinfoService.getCurrent());

        model.addAttribute("incomeGrades",systemDictionaryService.listItemsByDicSn("incomeGrade"));
        model.addAttribute("kidCounts",systemDictionaryService.listItemsByDicSn("kidCount"));
        model.addAttribute("educationBackgrounds",systemDictionaryService.listItemsByDicSn("educationBackground"));
        model.addAttribute("houseConditions",systemDictionaryService.listItemsByDicSn("houseCondition"));
        model.addAttribute("marriages",systemDictionaryService.listItemsByDicSn("marriage"));
        return "userInfo";
    }

    //保存基本信息
    @RequestMapping("basicInfo_save")
    @RequiredLogin
    @ResponseBody
    public JSONResult saveBasicInfo(Userinfo userinfo) {
        userinfoService.saveOrUpdate(userinfo);
        return new JSONResult();
    }
}
