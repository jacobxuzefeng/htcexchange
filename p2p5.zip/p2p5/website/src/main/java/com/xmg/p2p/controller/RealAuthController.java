package com.xmg.p2p.controller;

import com.xmg.p2p.base.domain.RealAuth;
import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.service.IRealAuthService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.util.RequiredLogin;
import com.xmg.p2p.util.UploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;

//前端:实名认证
@Controller
public class RealAuthController {

    @Autowired
    private IUserinfoService userinfoService;

    @Autowired
    private IRealAuthService realAuthService;

    @Autowired
    private ServletContext servletContext;

    //进入实名认证页面
    @RequestMapping("realAuth")
    @RequiredLogin
    public String gotoPage(Model model) {
        Userinfo current = userinfoService.getCurrent();
        //情况1:如果没有提交申请,进入申请页面
        if (!current.getHasRealAuth()) {
            //情况2:如果提交实名认证申请,还未审核,进入申请中页面
            if (current.getRealAuthId() == null) {
                return "realAuth";
            } else {
                model.addAttribute("auditing", true);
                return "realAuth_result";
            }
        } else {
            //情况3:如果已经实名认证,进入认证结果页面,显示实名认证信息
            model.addAttribute("realAuth", realAuthService.get(current.getRealAuthId()));
            model.addAttribute("auditing", false);
            return "realAuth_result";
        }
    }

    //实名认证申请
    @RequiredLogin
    @RequestMapping("realAuth_save")
    @ResponseBody
    public JSONResult apply(RealAuth r) {
        realAuthService.apply(r);
        return new JSONResult();
    }

    //上传实名认证图片
    @RequiredLogin
    @RequestMapping("uploadImage")
    @ResponseBody
    public String uploadImage(MultipartFile file) {
        String baseDir = "/upload";
        String fileName = UploadUtil.upload(file, servletContext.getRealPath(baseDir));
        return baseDir + "/" + fileName;
    }
}
