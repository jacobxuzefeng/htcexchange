package com.xmg.p2p.interceptor;

import com.xmg.p2p.base.util.UserContext;
import com.xmg.p2p.util.RequiredLogin;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//登录检查拦截器
public class CheckLoginInterceptor extends HandlerInterceptorAdapter {
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        if (handler instanceof HandlerMethod) {
            HandlerMethod hm = (HandlerMethod) handler;
            if (hm.getMethodAnnotation(RequiredLogin.class) != null && UserContext.getCurrentUser() == null) {
                response.sendRedirect("/login.html");
                return false;
            }
        }
        return true;
    }
}
