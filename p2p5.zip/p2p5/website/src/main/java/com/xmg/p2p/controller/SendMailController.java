package com.xmg.p2p.controller;

import com.xmg.p2p.base.service.IMailVerifyService;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.util.RequiredLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//前端:发送邮件
@Controller
public class SendMailController {

    @Autowired
    private IMailVerifyService mailVerifyService;
    @RequiredLogin
    @RequestMapping("sendEmail")
    @ResponseBody
    public JSONResult sendEMail(String email) {
        JSONResult jsonResult = new JSONResult();
        try {
            mailVerifyService.sendEMail(email);
        } catch (Exception e) {
            e.printStackTrace();
            jsonResult.mark(e.getMessage());
        }
        return jsonResult;
    }
}
