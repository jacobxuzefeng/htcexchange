package com.xmg.p2p.controller;

import com.xmg.p2p.base.domain.Logininfo;
import com.xmg.p2p.base.service.ILogininfoService;
import com.xmg.p2p.base.util.JSONResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

//前端:登录
@Controller
public class LogininfoController {

    @Autowired
    private ILogininfoService logininfoService;

    @RequestMapping("register")
    @ResponseBody
    public JSONResult register(String username, String password) {
        JSONResult jsonResult = new JSONResult();
        try {
            logininfoService.register(username, password);
        } catch (Exception e) {
            e.printStackTrace();
            jsonResult.mark(e.getMessage());
        }
        return jsonResult;
    }

    @RequestMapping("login")
    @ResponseBody
    public JSONResult login(String username, String password, HttpServletRequest request) {
        JSONResult jsonResult = new JSONResult();
        Logininfo current = logininfoService.login(username, password, request.getRemoteAddr(),Logininfo.USER_NORMAL);
        if (current == null) {
            jsonResult.mark("账户或密码错误");
        }
        return jsonResult;
    }

    @RequestMapping("checkUsernameExist")
    @ResponseBody
    public boolean checkUsernameExist(String username) {
        return !logininfoService.checkUsernameExist(username);
    }
}
