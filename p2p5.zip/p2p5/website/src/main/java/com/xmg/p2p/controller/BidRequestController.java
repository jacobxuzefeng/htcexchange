package com.xmg.p2p.controller;

import com.xmg.p2p.base.domain.Userinfo;
import com.xmg.p2p.base.service.IAccountService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.BidConst;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.business.domain.BidRequest;
import com.xmg.p2p.business.service.IBidRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;

//前端:借款申请
@Controller
public class BidRequestController {

    @Autowired
    private IUserinfoService userinfoService;
    @Autowired
    private IAccountService accountService;

    @Autowired
    private IBidRequestService bidRequestService;


    //进入借款申请页面
    @RequestMapping("borrowInfo")
    public String gotoApplyPage(Model model) {
        Userinfo current = userinfoService.getCurrent();
        //基本的四个因素
        if (!(current.getHasBasicInfo()
                && current.getHasRealAuth()
                && current.getHasVideoAuth()
                && current.getScore() >= BidConst.DEFAULT_CREDIT_BORROW_SCORE)) {
            return "redirect:borrow.do";
        }
        //是否存在一个借款请求
        if (current.getHasBidRequestInProcess()) {
            return "borrow_apply_result";
        }
        model.addAttribute("account", accountService.getCurrent());
        model.addAttribute("minBidRequestAmount", BidConst.SMALLEST_BIDREQUEST_AMOUNT);
        model.addAttribute("minBidAmount", BidConst.SMALLEST_BID_AMOUNT);
        return "borrow_apply";
    }

    //借款申请
    @RequestMapping("borrow_apply")
    public String apply(BidRequest br){
        bidRequestService.apply(br);
        return "redirect:borrowInfo.do";
    }

    @RequestMapping("borrow_bid")
    @ResponseBody
    public JSONResult bid(Long bidRequestId, BigDecimal amount) {
        this.bidRequestService.bid(bidRequestId, amount);
        return new JSONResult();
    }

}
