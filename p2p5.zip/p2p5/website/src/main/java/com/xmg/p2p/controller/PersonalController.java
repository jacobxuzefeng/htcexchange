package com.xmg.p2p.controller;


import com.xmg.p2p.base.service.IAccountService;
import com.xmg.p2p.base.service.IUserinfoService;
import com.xmg.p2p.base.util.JSONResult;
import com.xmg.p2p.util.RequiredLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//前端:个人中心
@Controller
public class PersonalController {
    @Autowired
    private IUserinfoService userinfoService;
    @Autowired
    private IAccountService accountService;


    //个人中心首页
    @RequiredLogin
    @RequestMapping("personal")
    public String personal(Model model) {
        model.addAttribute("userinfo", userinfoService.getCurrent());
        model.addAttribute("account", accountService.getCurrent());
        return "personal";
    }

    //绑定手机
    @RequiredLogin
    @RequestMapping("bindPhone")
    @ResponseBody
    public JSONResult bindPhone(String phoneNumber, String verifyCode) {
        JSONResult jsonResult = new JSONResult();
        try {
            userinfoService.bindPhone(phoneNumber, verifyCode);
        } catch (Exception e) {
            e.printStackTrace();
            jsonResult.mark(e.getMessage());
        }
        return jsonResult;
    }

    //绑定邮箱
    @RequestMapping("bindEmail")
    public String bindEmail(String uuid, Model model) {
        try {
            userinfoService.bindEmail(uuid);
            model.addAttribute("success", true);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("msg", e.getMessage());
            model.addAttribute("success", false);
        }
        return "checkmail_result";
    }
}
